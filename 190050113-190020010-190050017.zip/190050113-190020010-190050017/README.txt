P2P-Cyptocurrency-Simulation

install following packages:
numpy
networkx
matplotlib

To run simulator:-
    cd code
    python3 main.py

output:- details about succesfully mined block, which is added to primary chain is printed on console.
        after end of simulation, a file nmaed "log_tree.txt" contains information about all the blocks at a node

-> parameters in the __main__ part can be chnaged accordingly. Name of the parameters is self explanatory

To generate the graph of the network, un-comment line number 107
